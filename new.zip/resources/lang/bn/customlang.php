<?php

return [

    'name' => 'দোয়েল সমবায় সমিতি',
    'dashboard' => 'ড্যাশবোর্ড',
    'company' =>'প্রতিষ্ঠান',
    'companyprofile' =>'সংস্থা প্রোফাইল',
    'employee' =>'কর্মচারী',
    'member' =>'সদস্য',
    'LoanSection' =>' ঋণ বিভাগ',
    'Loan' =>'ঋণ',
    'share' =>'ভাগ',
    'MSP' =>'MSP',
    'deposit' =>'আমানত',
    'CollectionSection' =>'সংগ্রহ বিভাগ',
    'Saveing' =>'জমা',
    'Installment' =>'কিস্তি',
    'Accounting' =>'হিসাবরক্ষণ',
    'DailyExpense' =>'দৈনিক ব্যয়',
    'EmployeeSalary' =>'কর্মচারী বেতন',
    'CloseMembership' =>'সদস্যতা বন্ধ করুন',
    'ReportPaper' =>'রিপোর্ট পেপার',
    'Today' =>'আজ',
    'Monthly' =>'মাসিক',
    'Yearly' =>'বার্ষিক',
    '' =>'',
    '' =>'',
    '' =>'',
    '' =>'',

];
