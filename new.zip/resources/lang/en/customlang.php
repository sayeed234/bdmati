<?php

return [

    'name' => 'Doyle Multipurpose',
    'dashboard' => 'Dashboard',
    'company' =>'Company',
    'companyprofile' =>'Company Profile',
    'employee' =>'Employee',
    'member' =>'Member',
    'LoanSection' =>' Loan Section',
    'Loan' =>'Loan',
    'share' =>'Share',
    'MSP' =>'MSP',
    'deposit' =>'Deposit',
    'CollectionSection' =>'Collection Section',
    'Saveing' =>'Savings',
    'Installment' =>'Installment',
    'Accounting' =>'Accounting',
    'DailyExpense' =>'Daily Expense',
    'EmployeeSalary' =>'Employee Salary',
    'CloseMembership' =>'Close Membership',
    'ReportPaper' =>'Report Paper',
    'Today' =>'Today',
    'Monthly' =>'Monthly',
    'Yearly' =>'Yearly',

];
