        <span >
        <div id="contact" class="contact">
            <div class="section secondary-section">
			    <div class="container">
                    <div class="span9 center contact-info">
                        <p>59-Kalabagan 1st Lane</p>
                        <p class="info-mail">plabon8866@gmail.com</p>
                        <p>01912-619757, 01676-588917, 01744-884313</p>
                        {{-- <div class="title">
                            <h3>We Are Social</h3>
                        </div> --}}
                    </div>
                    {{-- <div class="row-fluid centered">
                        <ul class="social">
                            <li>
                                <a href="">
                                    <span class="icon-facebook-circled"></span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="icon-twitter-circled"></span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="icon-linkedin-circled"></span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="icon-pinterest-circled"></span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="icon-dribbble-circled"></span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="icon-gplus-circled"></span>
                                </a>
                            </li>
                        </ul>
                    </div> --}}
                </div>
                </div>
                </div>
                </span>