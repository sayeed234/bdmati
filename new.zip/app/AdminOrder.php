<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminOrder extends Model
{
    //
}
