<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
    //
}
